import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum OriginalStorePalette {
    static let background = Color(red: 0.025, green: 0.012, blue: 0.045)
    static let surface = Color(red: 0.075, green: 0.035, blue: 0.125)
    static let raised = Color(red: 0.16, green: 0.075, blue: 0.25)
    static let line = Color.white.opacity(0.085)
    static let muted = Color(red: 0.68, green: 0.59, blue: 0.78)
    static let soft = Color(red: 0.82, green: 0.72, blue: 1.0)
    static let white = Color(red: 0.96, green: 0.96, blue: 0.97)
}

private struct OriginalStoreHeroBanner: View {
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            AsyncImage(url: URL(string: "https://media.discordapp.net/attachments/1572997596191002674/1573384892866105354/IMG_1049.png?format=webp&quality=lossless&width=708&height=1536")) { phase in
                if let image = phase.image { image.resizable().scaledToFill() } else { LinearGradient(colors: [Color.purple.opacity(0.65), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing) }
            }.frame(height: 148).clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.82)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 4) { Text("ORIGINAL STORE").font(.system(size: 22, weight: .black, design: .rounded)); Text("Patches e texturas, sempre organizados.").font(.system(size: 12, weight: .medium)).opacity(0.82) }.foregroundStyle(.white).padding(16)
            AsyncImage(url: URL(string: "https://cdn.pfps.gg/banners/87146-755552-animegif.gif")) { phase in if let image = phase.image { image.resizable().scaledToFill() } }.frame(width: 54, height: 54).clipShape(Circle()).overlay(Circle().stroke(.white.opacity(0.7), lineWidth: 2)).padding(14).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
        }.clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous)).overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.purple.opacity(0.55), lineWidth: 1))
    }
}

private enum StoreTab: String, CaseIterable, Identifiable {
    case patches
    case textures
    case global
    case info
    case tutorial

    var id: String { rawValue }
    var title: String {
        switch self {
        case .patches: return "Patches"
        case .textures: return "Texturas"
        case .global: return "Global"
        case .info: return "Info"
        case .tutorial: return "Tutorial"
        }
    }
    var icon: String {
        switch self {
        case .patches: return "square.stack.3d.up.fill"
        case .textures: return "square.3.layers.3d"
        case .global: return "bell.badge.fill"
        case .info: return "info.circle.fill"
        case .tutorial: return "book.closed.fill"
        }
    }
    var subtitle: String {
        switch self {
        case .patches: return "Seu catÃ¡logo, organizado por categoria."
        case .textures: return "Importe e organize arquivos de textura .3105."
        case .global: return "Comunicados publicados pela Original Store."
        case .info: return "LicenÃ§a, dispositivo e estado da sessÃ£o."
        case .tutorial: return "OrientaÃ§Ãµes de uso e avisos importantes."
        }
    }
}

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @ObservedObject private var remoteIntegration = RemoteIntegration.shared

    @State private var selectedTab: StoreTab = .patches
    @State private var activeSheet: StoreSheet?
    @State private var activeOperation: PatchOperationPresentation?
    @State private var patchSearchText = ""
    @State private var selectedCategoryFilter = "Todas"
    @State private var selectedStatusFilter: PatchStatusFilter = .all
    @State private var patchActionStates: [String: PatchActionState] = [:]
    @State private var passwordValue = ""
    @State private var restorePatch: RemotePatch?
    @State private var restoreChangedPaths: [String] = []
    @State private var showRestoreConfirmation = false
    @State private var showUnlinkConfirmation = false

    var body: some View {
        ZStack {
            AmbientMotionBackground()
            if remoteIntegration.isRestoringSession {
                restoringSession
                    .transition(.opacity)
            } else if let state = accessGateKind {
                AccessStatusView(state: state, service: remoteIntegration) {
                    Task { await remoteIntegration.refreshSessionNow() }
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else if remoteIntegration.licensed {
                authenticatedStore
                    .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
            } else {
                OriginalStoreKeyEntryView(service: remoteIntegration) { patch in
                    requestToggle(patch, enabled: false)
                }
                .transition(reduceMotion ? .opacity : .opacity.combined(with: .scale(scale: 0.985)))
            }
            if let activeOperation {
                PatchOperationOverlay(operation: activeOperation, reduceMotion: reduceMotion)
                    .transition(.opacity)
                    .zIndex(20)
            }
        }
        .preferredColorScheme(.dark)
        .tint(OriginalStorePalette.white)
        .task {
            await remoteIntegration.restoreSavedSession()
            await remoteIntegration.monitor()
        }
        .onChange(of: remoteIntegration.licensed) { isLicensed in
            guard isLicensed else { return }
            withAnimation(reduceMotion ? nil : .spring(response: 0.36, dampingFraction: 0.86)) {
                selectedTab = .patches
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { await remoteIntegration.refreshSessionNow() }
        }
        .sheet(item: $activeSheet) { sheet in
            switch sheet.content {
                case let .confirmation(patch, enabled):
                    PatchConfirmationSheet(patch: patch, isInjection: enabled, onCancel: {
                        activeSheet = nil
                    }, onConfirm: {
                        activeSheet = nil
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .medium).impactOccurred() }
                        Task { await performToggle(patch, enabled: enabled, riskConfirmed: enabled && patch.risk) }
                    })
            case let .details(patch):
                PatchDetailsSheet(
                    patch: patch,
                    category: categoryName(patch),
                    statusTitle: statusTitle(for: patch),
                    statusColor: statusColor(for: patch),
                    isActive: remoteIntegration.isPatchActive(patch.id)
                ) {
                    activeSheet = nil
                }
            case let .result(result):
                PatchOperationResultSheet(result: result, onClose: {
                    activeSheet = nil
                }, onRefresh: {
                    activeSheet = nil
                    Task { await remoteIntegration.refreshSessionNow() }
                })
            case let .password(patch):
                PatchPasswordSheet(
                    patchName: patch.name,
                    password: $passwordValue,
                    onCancel: {
                        remoteIntegration.discardPendingPackage(for: patch.id)
                        passwordValue = ""
                        activeSheet = nil
                    },
                    onUnlock: {
                        let value = passwordValue
                        activeSheet = nil
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                        Task { await performToggle(patch, enabled: true, password: value, riskConfirmed: true) }
                    }
                )
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
            }
        }
        .alert("Arquivos alterados", isPresented: $showRestoreConfirmation) {
            Button("Cancelar", role: .cancel) { restorePatch = nil }
            Button("Restaurar mesmo assim", role: .destructive) {
                guard let patch = restorePatch else { return }
                Task { await performToggle(patch, enabled: false, allowChangedTargets: true) }
            }
        } message: {
            Text(restoreChangedPaths.prefix(5).joined(separator: "\n") + (restoreChangedPaths.count > 5 ? "\nâ€¦" : "") + "\n\nAlguns arquivos mudaram depois da aplicaÃ§Ã£o. Restaurar substituirÃ¡ essas alteraÃ§Ãµes pelos backups originais.")
        }
        .alert("Desvincular dispositivo?", isPresented: $showUnlinkConfirmation) {
            Button("Cancelar", role: .cancel) {}
            Button("Desvincular", role: .destructive) {
                Task { await remoteIntegration.unlink() }
            }
        } message: {
            Text("A key deixarÃ¡ de estar vinculada a este aparelho. Os patches jÃ¡ aplicados permanecerÃ£o disponÃ­veis para restauraÃ§Ã£o local.")
        }

    }

    private var accessGateKind: AccessGateKind? {
        let status = remoteIntegration.globalStatus.lowercased()
        let code = remoteIntegration.licenseErrorCode?.lowercased()
        if status == "banned" || code == "device_banned" { return .banned }
        switch code {
        case "key_expired", "license_expired": return .keyExpired
        case "key_revoked", "license_revoked": return .keyRevoked
        case "key_not_found", "license_not_found", "key_deleted": return .keyMissing
        case "device_limit_reached", "max_devices_reached": return .deviceLimit
        case "hwid_mismatch", "device_mismatch": return .deviceMismatch
        case "license_inactive": return .keyDisabled
        case "invalid_key", "license_invalid": return .invalidKey
        case "maintenance": return .maintenance
        case "offline", "service_offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        default: break
        }
        if !remoteIntegration.isConfigured { return .configuration }
        if !remoteIntegration.hasServiceResponse { return .connection }
        guard !remoteIntegration.serviceAllowed else { return nil }
        switch status {
        case "maintenance": return .maintenance
        case "offline": return .offline
        case "updating", "update": return .updating
        case "old_version", "old-version": return .oldVersion
        case "banned": return .banned
        default: return .offline
        }
    }

    private var restoringSession: some View {
        VStack(spacing: 22) {
            OriginalStoreBrandMark(size: 68)
            ProgressView().tint(OriginalStorePalette.white).scaleEffect(1.05)
            VStack(spacing: 5) {
                Text("Verificando sua licenÃ§a")
                    .font(.system(size: 19, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.white)
                Text("\(remoteIntegration.storeName) Â· sessÃ£o protegida")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(OriginalStorePalette.muted)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(28)
    }

    private var authenticatedStore: some View {
        VStack(spacing: 0) {
            storeHeader
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    OriginalStoreHeroBanner()
                    switch selectedTab {
                    case .patches: patchCatalog
                    case .textures: texturesLibrary
                    case .global: globalFeed
                    case .info: licenseInfo
                    case .tutorial: tutorialView
                    }
                    Text("DESENVOLVIDO POR @OriginalStore")
                        .font(.system(size: 10, weight: .semibold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(OriginalStorePalette.muted.opacity(0.8))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 8)
                        .padding(.bottom, 12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
            }
            .refreshable { await remoteIntegration.refreshCatalog(force: true) }
            bottomNavigation
        }
    }

    private var storeHeader: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack(spacing: 10) {
                OriginalStoreBrandMark(size: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(remoteIntegration.storeName)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .foregroundStyle(OriginalStorePalette.white)
                    Text("LOJA DIGITAL")
                        .font(.system(size: 8, weight: .semibold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(OriginalStorePalette.muted)
                }
                Spacer(minLength: 4)
                HStack(spacing: 6) {
                    Circle().fill(remoteIntegration.serviceAllowed ? OriginalStorePalette.white : OriginalStorePalette.muted)
                        .frame(width: 5, height: 5)
                    Text(remoteIntegration.serviceAllowed ? "OK" : "SYNC")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .tracking(0.8)
                        .foregroundStyle(OriginalStorePalette.soft)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 7)
                .background(OriginalStorePalette.raised, in: Capsule())
                if let discordURL = remoteIntegration.discordURL {
                    Link(destination: discordURL) {
                        DiscordGlyph(size: 18)
                            .frame(width: 36, height: 36)
                            .background(OriginalStorePalette.surface, in: Circle())
                            .overlay(Circle().stroke(OriginalStorePalette.line, lineWidth: 1))
                    }
                    .accessibilityLabel("Abrir comunidade no Discord")
                }
            }
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(selectedTab.title)
                        .font(.system(size: 32, weight: .bold, design: .rounded))
                        .tracking(-0.8)
                        .foregroundStyle(OriginalStorePalette.white)
                    Text(selectedTab == .global
                         ? "Comunicados publicados por \(remoteIntegration.storeName)."
                         : selectedTab.subtitle)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundStyle(OriginalStorePalette.muted)
                }
                Spacer(minLength: 12)
                Button {
                    if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                    Task { await remoteIntegration.refreshSessionNow() }
                } label: {
                    Group {
                        if remoteIntegration.isSyncing {
                            ProgressView().controlSize(.small).tint(OriginalStorePalette.white)
                        } else {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 14, weight: .semibold))
                        }
                    }
                    .foregroundStyle(OriginalStorePalette.white)
                    .frame(width: 42, height: 42)
                    .background(OriginalStorePalette.surface, in: Circle())
                    .overlay(Circle().stroke(OriginalStorePalette.line, lineWidth: 1))
                }
                .disabled(remoteIntegration.isSyncing)
                .accessibilityLabel(remoteIntegration.isSyncing ? "Sincronizando" : "Sincronizar agora")
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
        .padding(.bottom, 18)
    }

    private var patchCatalog: some View {
        VStack(alignment: .leading, spacing: 14) {
            Button {
                Task { await remoteIntegration.refreshCatalog(force: true) }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 21, weight: .bold))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Atualizar patches")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                        Text(remoteIntegration.isSyncing ? "Sincronizando catálogo…" : "Buscar novidades agora")
                            .font(.system(size: 11, weight: .medium))
                            .opacity(0.78)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                }
                .foregroundStyle(.white)
                .padding(16)
                .background(LinearGradient(colors: [Color(red: 0.55, green: 0.18, blue: 0.95), Color(red: 0.28, green: 0.06, blue: 0.58)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(remoteIntegration.isSyncing)

            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("CATÃLOGO \(remoteIntegration.storeName.uppercased())")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2.0)
                        .foregroundStyle(OriginalStorePalette.muted)
                    Text("\(filteredPatches.count) \(filteredPatches.count == 1 ? "patch" : "patches")")
                        .font(.system(size: 18, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.white)
                }
                Spacer(minLength: 8)
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 11, weight: .semibold))
                    Text("iOS \(remoteIntegration.iosVersion)")
                        .font(.system(size: 9, weight: .semibold, design: .rounded))
                }
                .foregroundStyle(OriginalStorePalette.soft)
                .padding(.horizontal, 9)
                .padding(.vertical, 7)
                .background(OriginalStorePalette.surface, in: Capsule())
            }

            HStack(spacing: 7) {
                ZStack {
                    Circle().fill(syncIndicatorColor.opacity(0.16)).frame(width: 20, height: 20)
                    Circle().fill(syncIndicatorColor).frame(width: 6, height: 6)
                }
                Text(syncStatusText)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.muted)
                    .lineLimit(1)
                Spacer(minLength: 0)
                if let lastSync = remoteIntegration.lastCatalogSync {
                    Text(DateFormatter.localizedString(from: lastSync, dateStyle: .none, timeStyle: .short))
                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                        .foregroundStyle(OriginalStorePalette.muted.opacity(0.82))
                        .accessibilityLabel("Ãšltima atualizaÃ§Ã£o Ã s \(DateFormatter.localizedString(from: lastSync, dateStyle: .none, timeStyle: .short))")
                }
            }
            .padding(.horizontal, 2)
            .accessibilityElement(children: .combine)

            HStack(spacing: 9) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(OriginalStorePalette.muted)
                TextField("Buscar patches", text: $patchSearchText)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .submitLabel(.search)
                    .accessibilityLabel("Buscar patches por nome ou descriÃ§Ã£o")
                if !patchSearchText.isEmpty {
                    Button {
                        patchSearchText = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(OriginalStorePalette.muted)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Limpar busca")
                }
            }
            .padding(.horizontal, 13)
            .frame(height: 46)
            .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 7) {
                    ForEach(PatchStatusFilter.allCases, id: \.self) { filter in
                        filterChip(filter.title, selected: selectedStatusFilter == filter) {
                            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                                selectedStatusFilter = filter
                            }
                        }
                    }
                }
                .padding(.vertical, 1)
            }
            .accessibilityLabel("Filtrar patches por status")

            if !categoryNames.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 7) {
                        filterChip("Todas", selected: selectedCategoryFilter == "Todas") {
                            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                                selectedCategoryFilter = "Todas"
                            }
                        }
                        ForEach(categoryNames, id: \.self) { category in
                            filterChip(category, selected: selectedCategoryFilter == category) {
                                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                                    selectedCategoryFilter = category
                                }
                            }
                        }
                    }
                    .padding(.vertical, 1)
                }
                .accessibilityLabel("Filtrar patches por categoria")
            }

            if let message = remoteIntegration.gateMessage, !message.isEmpty {
                statusNotice(message, symbol: "exclamationmark.circle")
            }
            if let error = remoteIntegration.errorMessage, !error.isEmpty {
                statusNotice(error, symbol: "arrow.triangle.2.circlepath")
            }

            if filteredPatches.isEmpty {
                if sortedPatches.isEmpty && remoteIntegration.isSyncing {
                    VStack(spacing: 10) {
                        PatchSkeletonCard()
                        PatchSkeletonCard()
                    }
                    .accessibilityLabel("Carregando catÃ¡logo de patches")
                } else if sortedPatches.isEmpty && remoteIntegration.errorMessage != nil {
                    emptyState(
                        symbol: "wifi.exclamationmark",
                        title: "NÃ£o foi possÃ­vel carregar",
                        message: remoteIntegration.errorMessage ?? "Confira a conexÃ£o e sincronize novamente."
                    )
                    Button {
                        if !reduceMotion { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
                        Task { await remoteIntegration.refreshSessionNow() }
                    } label: {
                        Label("Tentar sincronizar", systemImage: "arrow.clockwise")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(OriginalStorePalette.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                    }
                    .buttonStyle(.plain)
                } else if sortedPatches.isEmpty {
                    emptyState(
                        symbol: "square.stack.3d.up",
                        title: "Seu catÃ¡logo estÃ¡ vazio",
                        message: "Quando um patch for publicado no painel, ele aparecerÃ¡ aqui, organizado pela categoria escolhida."
                    )
                } else {
                    emptyState(
                        symbol: "line.3.horizontal.decrease.circle",
                        title: "Nenhum patch encontrado",
                        message: "Tente mudar a busca ou os filtros de status e categoria."
                    )
                    Button {
                        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
                            patchSearchText = ""
                            selectedCategoryFilter = "Todas"
                            selectedStatusFilter = .all
                        }
                    } label: {
                        Text("Limpar busca e filtros")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(OriginalStorePalette.soft)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.plain)
                }
            } else {
                ForEach(filteredCategoryNames, id: \.self) { category in
                    categorySection(category, patches: filteredPatches.filter { categoryName($0) == category })
                        .transition(reduceMotion ? .opacity : .opacity.combined(with: .move(edge: .bottom)))
                }
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: filteredPatches.map(\.id))
    }

    private var globalFeed: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("MURAL GLOBAL")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(OriginalStorePalette.muted)
                Spacer()
                Text("\(remoteIntegration.announcements.count) avisos")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.soft)
            }
            if remoteIntegration.announcements.isEmpty {
                emptyState(
                    symbol: "bell.slash",
                    title: "Nenhum aviso por enquanto",
                    message: "AnÃºncios publicados no painel aparecerÃ£o nesta aba."
                )
            } else {
                ForEach(remoteIntegration.announcements) { item in
                    VStack(alignment: .leading, spacing: 13) {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "bell.badge.fill")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(OriginalStorePalette.white)
                                .frame(width: 36, height: 36)
                                .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.title)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundStyle(OriginalStorePalette.white)
                                if let createdAt = item.createdAt {
                                    Text(formattedDate(createdAt))
                                        .font(.system(size: 10, weight: .medium, design: .monospaced))
                                        .foregroundStyle(OriginalStorePalette.muted)
                                }
                            }
                            Spacer(minLength: 0)
                        }
                        Rectangle().fill(OriginalStorePalette.line).frame(height: 1)
                        Text(item.message)
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(OriginalStorePalette.soft)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(17)
                    .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
                }
            }
        }
    }

    private var licenseInfo: some View {
        VStack(alignment: .leading, spacing: 17) {
            VStack(alignment: .leading, spacing: 4) {
                Text("SESSÃƒO E DISPOSITIVO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(OriginalStorePalette.muted)
                Text("Tudo em um sÃ³ lugar")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.white)
            }
            VStack(spacing: 0) {
                infoRow(symbol: "storefront.fill", title: "Loja", value: remoteIntegration.storeName)
                infoDivider
                infoRow(symbol: "checkmark.shield.fill", title: "LicenÃ§a", value: remoteIntegration.licensed ? "Ativa neste aparelho" : "Aguardando validaÃ§Ã£o")
                infoDivider
                infoRow(symbol: "key.fill", title: "Key", value: remoteIntegration.maskedLicenseKey, monospaced: true)
                infoDivider
                infoRow(symbol: "calendar", title: "Expira em", value: formattedDate(remoteIntegration.licenseExpiresAt))
                infoDivider
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    infoRow(
                        symbol: "timer",
                        title: "Tempo restante",
                        value: remainingLicenseTime(until: remoteIntegration.licenseExpiresAt, now: timeline.date),
                        monospaced: true
                    )
                }
                if let maxDevices = remoteIntegration.licenseMaxDevices {
                    infoDivider
                    infoRow(symbol: "iphone.gen3", title: "Limite de aparelhos", value: "\(maxDevices) \(maxDevices == 1 ? "aparelho" : "aparelhos")")
                }
                infoDivider
                infoRow(symbol: "iphone", title: "Modelo", value: remoteIntegration.deviceModelName)
                infoDivider
                infoRow(symbol: "gearshape", title: "VersÃ£o do iOS", value: remoteIntegration.iosVersion)
                infoDivider
                infoRow(symbol: "number", title: "ID do aparelho", value: "â€¢â€¢â€¢â€¢\(remoteIntegration.deviceIdentifierSuffix)", monospaced: true)
                infoDivider
                infoRow(symbol: "arrow.triangle.2.circlepath", title: "Ãšltima verificaÃ§Ã£o", value: formattedDate(remoteIntegration.lastVerifiedAt))
            }
            .padding(.horizontal, 16)
            .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

            if let discordURL = remoteIntegration.discordURL {
                Link(destination: discordURL) {
                    HStack(spacing: 12) {
                        DiscordGlyph(size: 20)
                            .frame(width: 40, height: 40)
                            .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Comunidade no Discord")
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(OriginalStorePalette.white)
                            Text("Suporte e novidades da loja")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(OriginalStorePalette.muted)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(OriginalStorePalette.muted)
                    }
                    .padding(13)
                    .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
                }
            }

            Button {
                showUnlinkConfirmation = true
            } label: {
                HStack(spacing: 9) {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                    Text("Desvincular dispositivo")
                    Spacer()
                    Image(systemName: "arrow.up.right")
                        .font(.system(size: 10, weight: .semibold))
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(OriginalStorePalette.soft)
                .padding(.horizontal, 16)
                .padding(.vertical, 15)
                .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
            }
            .disabled(remoteIntegration.isLoading)
        }
    }

    private var tutorialView: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                Image(systemName: "book.closed.fill")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(OriginalStorePalette.white)
                    .frame(width: 42, height: 42)
                    .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("COMO UTILIZAR")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(1.8)
                        .foregroundStyle(OriginalStorePalette.muted)
                    Text("Passo a passo")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.white)
                }
            }

            VStack(spacing: 0) {
                tutorialStep(number: "01", title: "Abra o FF", message: "Entre no FF e aguarde o carregamento atÃ© 40%.", symbol: "gamecontroller.fill")
                tutorialDivider
                tutorialStep(number: "02", title: "Ative o patch", message: "Volte ao aplicativo e ative o patch desejado.", symbol: "switch.2")
                tutorialDivider
                tutorialStep(number: "03", title: "Desative no lobby", message: "Retorne ao FF e, quando entrar no lobby, desative o patch.", symbol: "arrow.uturn.backward")
            }
            .padding(.horizontal, 15)
            .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "info.circle.fill")
                    .font(.system(size: 14, weight: .semibold))
                Text("Esse mÃ©todo Ã© obrigatÃ³rio somente para HS.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .foregroundStyle(OriginalStorePalette.soft)
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(OriginalStorePalette.raised.opacity(0.72), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 14, weight: .bold))
                Text("Usar de forma indevida pode ocasionar puniÃ§Ãµes.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .foregroundStyle(Color(red: 1.0, green: 0.62, blue: 0.31))
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.09), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
        }
    }

    private var tutorialDivider: some View {
        Rectangle().fill(OriginalStorePalette.line).frame(height: 1).padding(.leading, 51)
    }

    private func tutorialStep(number: String, title: String, message: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle().fill(OriginalStorePalette.raised).frame(width: 38, height: 38)
                Image(systemName: symbol).font(.system(size: 14, weight: .semibold)).foregroundStyle(OriginalStorePalette.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 7) {
                    Text(number).font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(OriginalStorePalette.muted)
                    Text(title).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(OriginalStorePalette.white)
                }
                Text(message)
                    .font(.system(size: 11, weight: .regular))
                    .lineSpacing(3)
                    .foregroundStyle(OriginalStorePalette.muted)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.top, 2)
            Spacer(minLength: 0)
        }
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var bottomNavigation: some View {
        HStack(spacing: 4) {
            ForEach(StoreTab.allCases) { tab in
                Button {
                    withAnimation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.82)) {
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 6) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 18, weight: .semibold))
                            .frame(height: 20)
                        Text(tab.title)
                            .font(.system(size: 10, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selectedTab == tab ? OriginalStorePalette.background : OriginalStorePalette.muted)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background {
                        if selectedTab == tab {
                            Capsule().fill(OriginalStorePalette.white)
                        }
                    }
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityAddTraits(selectedTab == tab ? .isSelected : [])
            }
        }
        .padding(6)
        .background(OriginalStorePalette.surface, in: Capsule())
        .overlay(Capsule().stroke(OriginalStorePalette.line, lineWidth: 1))
        .padding(.horizontal, 20)
        .padding(.top, 9)
        .padding(.bottom, 8)
        .background(OriginalStorePalette.background.opacity(0.96))
    }

    private var texturesLibrary: some View {
        TexturesLibraryView()
    }

    private var sortedPatches: [RemotePatch] {
        remoteIntegration.patchesForDisplay.sorted {
            let left = categoryName($0)
            let right = categoryName($1)
            if left != right { return left.localizedStandardCompare(right) == .orderedAscending }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    private func categoryName(_ patch: RemotePatch) -> String {
        let value = patch.category?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return value.isEmpty ? "Sem categoria" : value
    }

    private var categoryNames: [String] {
        Array(Set(sortedPatches.map(categoryName))).sorted()
    }

    private var filteredPatches: [RemotePatch] {
        let query = patchSearchText.trimmingCharacters(in: .whitespacesAndNewlines)
        return sortedPatches.filter { patch in
            let matchesQuery = query.isEmpty || patch.name.localizedStandardContains(query)
                || (patch.description?.localizedStandardContains(query) ?? false)
            let matchesCategory = selectedCategoryFilter == "Todas" || categoryName(patch) == selectedCategoryFilter
            let status = patch.status.lowercased()
            let matchesStatus: Bool
            switch selectedStatusFilter {
            case .all: matchesStatus = true
            case .available: matchesStatus = status == "ativo"
            case .updating: matchesStatus = status == "atualizando"
            case .disabled: matchesStatus = status != "ativo" && status != "atualizando"
            }
            return matchesQuery && matchesCategory && matchesStatus
        }
    }

    private var filteredCategoryNames: [String] {
        Array(Set(filteredPatches.map(categoryName))).sorted()
    }

    private var syncStatusText: String {
        if remoteIntegration.isSyncing { return "Sincronizando catÃ¡logo e licenÃ§a" }
        if remoteIntegration.errorMessage != nil { return "Falha na Ãºltima sincronizaÃ§Ã£o" }
        return remoteIntegration.lastCatalogSync == nil ? "Aguardando sincronizaÃ§Ã£o" : "CatÃ¡logo atualizado"
    }

    private var syncIndicatorColor: Color {
        if remoteIntegration.isSyncing { return Color(red: 0.98, green: 0.66, blue: 0.24) }
        if remoteIntegration.errorMessage != nil { return Color(red: 0.94, green: 0.35, blue: 0.36) }
        return Color(red: 0.30, green: 0.78, blue: 0.49)
    }

    private func filterChip(_ title: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                if selected { Image(systemName: "checkmark").font(.system(size: 8, weight: .bold)) }
                Text(title)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .lineLimit(1)
                    .fixedSize(horizontal: true, vertical: false)
            }
            .foregroundStyle(selected ? OriginalStorePalette.background : OriginalStorePalette.soft)
            .padding(.horizontal, 11)
            .frame(height: 31)
            .background(selected ? OriginalStorePalette.white : OriginalStorePalette.surface, in: Capsule())
            .overlay(Capsule().stroke(selected ? Color.clear : OriginalStorePalette.line, lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func categorySection(_ title: String, patches: [RemotePatch]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(title.uppercased())
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(OriginalStorePalette.muted)
                Spacer()
                Text(String(format: "%02d", patches.count))
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(OriginalStorePalette.muted.opacity(0.8))
            }
            ForEach(patches) { patch in patchCard(patch) }
        }
    }

    private func patchCard(_ patch: RemotePatch) -> some View {
        let isActive = remoteIntegration.isPatchActive(patch.id)
        let isAvailable = patch.status.lowercased() == "ativo"
        let actionState = patchActionStates[patch.id]
        let isBusy = remoteIntegration.isPatchBusy(patch.id) || actionState != nil
        let categoryConflict = remoteIntegration.activePatchConflict(for: patch)
        let successGreen = Color(red: 0.30, green: 0.78, blue: 0.49)
        return HStack(alignment: .center, spacing: 10) {
            Button {
                activeSheet = StoreSheet(content: .details(patch))
            } label: {
                HStack(alignment: .center, spacing: 11) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(OriginalStorePalette.raised)
                            .frame(width: 44, height: 44)
                        Image(systemName: "square.stack.3d.up.fill")
                            .font(.system(size: 17, weight: .medium))
                            .foregroundStyle(OriginalStorePalette.white)
                    }
                    VStack(alignment: .leading, spacing: 7) {
                        HStack(alignment: .firstTextBaseline, spacing: 5) {
                            Text(patch.name)
                                .font(.system(size: 14, weight: .semibold, design: .rounded))
                                .foregroundStyle(OriginalStorePalette.white)
                                .lineLimit(2)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                            Image(systemName: "info.circle")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(OriginalStorePalette.muted)
                                .accessibilityHidden(true)
                        }
                        ViewThatFits(in: .horizontal) {
                            HStack(spacing: 6) {
                                patchBadge(title: statusTitle(for: patch), color: statusColor(for: patch), symbol: statusSymbol(for: patch))
                                patchBadge(
                                    title: patch.risk ? "Risco" : "Seguro",
                                    color: patch.risk ? Color.orange : successGreen,
                                    symbol: patch.risk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill"
                                )
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                patchBadge(title: statusTitle(for: patch), color: statusColor(for: patch), symbol: statusSymbol(for: patch))
                                patchBadge(
                                    title: patch.risk ? "Risco" : "Seguro",
                                    color: patch.risk ? Color.orange : successGreen,
                                    symbol: patch.risk ? "exclamationmark.triangle.fill" : "checkmark.shield.fill"
                                )
                            }
                        }
                        if (patch.version?.isEmpty == false) || isActive {
                            ViewThatFits(in: .horizontal) {
                                HStack(spacing: 6) {
                                    if let version = patch.version, !version.isEmpty {
                                        patchBadge(title: "VersÃ£o \(version)", color: OriginalStorePalette.muted, symbol: "tag.fill")
                                    }
                                    if isActive {
                                        patchBadge(title: "Aplicado", color: successGreen, symbol: "checkmark.circle.fill")
                                    }
                                }
                                VStack(alignment: .leading, spacing: 5) {
                                    if let version = patch.version, !version.isEmpty {
                                        patchBadge(title: "VersÃ£o \(version)", color: OriginalStorePalette.muted, symbol: "tag.fill")
                                    }
                                    if isActive {
                                        patchBadge(title: "Aplicado", color: successGreen, symbol: "checkmark.circle.fill")
                                    }
                                }
                            }
                        }
                        if let categoryConflict, !isActive {
                            Label("Desative \(categoryConflict) para trocar", systemImage: "lock.fill")
                                .font(.system(size: 9, weight: .medium, design: .rounded))
                                .foregroundStyle(OriginalStorePalette.muted)
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Detalhes do patch \(patch.name)")
            .accessibilityHint("Mostra categoria, descriÃ§Ã£o, versÃ£o e status do patch.")
            .layoutPriority(1)

            Group {
                if isBusy {
                    ProgressView()
                        .controlSize(.small)
                        .tint(successGreen)
                        .accessibilityLabel(actionState?.title ?? "OperaÃ§Ã£o de patch em andamento")
                } else {
                    Toggle(
                        "",
                        isOn: Binding(
                            get: { remoteIntegration.isPatchActive(patch.id) },
                            set: { requestToggle(patch, enabled: $0) }
                        )
                    )
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .tint(successGreen)
                    .accessibilityLabel(isActive ? "Desativar e restaurar \(patch.name)" : "Ativar \(patch.name)")
                    .accessibilityHint(categoryConflict.map { "\($0) jÃ¡ estÃ¡ ativo nesta categoria. Desative-o antes de ativar este patch." } ?? "SerÃ¡ solicitada confirmaÃ§Ã£o antes de injetar ou desinjetar.")
                    .disabled((!isActive && !isAvailable) || (!isActive && !remoteIntegration.licensed) || (!isActive && categoryConflict != nil))
                }
            }
            .frame(width: 58, height: 54, alignment: .center)
            .accessibilityElement(children: .contain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, minHeight: 100, alignment: .center)
        .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .stroke(isActive ? successGreen.opacity(0.78) : OriginalStorePalette.line, lineWidth: isActive ? 1.5 : 1)
        }
        .shadow(color: isActive && !reduceMotion ? successGreen.opacity(0.19) : .clear, radius: isActive ? 18 : 0, y: 2)
        .opacity((!isAvailable && !isActive) ? 0.76 : 1)
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.82), value: isActive)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: isBusy)
    }

    private func patchBadge(title: String, color: Color, symbol: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: symbol).font(.system(size: 8, weight: .bold))
            Text(title)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .fixedSize(horizontal: true, vertical: false)
        }
            .foregroundStyle(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(color.opacity(0.13), in: Capsule())
            .overlay(Capsule().stroke(color.opacity(0.20), lineWidth: 0.7))
    }

    private func statusTitle(for patch: RemotePatch) -> String {
        switch patch.status.lowercased() {
        case "ativo": return "DisponÃ­vel"
        case "atualizando": return "Atualizando"
        default: return "Desativado"
        }
    }

    private func statusColor(for patch: RemotePatch) -> Color {
        switch patch.status.lowercased() {
        case "ativo": return Color(red: 0.30, green: 0.78, blue: 0.49)
        case "atualizando": return Color(red: 0.98, green: 0.66, blue: 0.24)
        default: return Color(red: 0.94, green: 0.35, blue: 0.36)
        }
    }

    private func statusSymbol(for patch: RemotePatch) -> String {
        switch patch.status.lowercased() {
        case "ativo": return "checkmark.circle.fill"
        case "atualizando": return "arrow.triangle.2.circlepath"
        default: return "xmark.circle.fill"
        }
    }

    private func requestToggle(_ patch: RemotePatch, enabled: Bool) {
        guard !enabled || patch.status.lowercased() == "ativo" else { return }
        if enabled, let conflict = remoteIntegration.activePatchConflict(for: patch) {
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: false,
                isInjection: true,
                message: "JÃ¡ existe um patch ativo nesta categoria: \(conflict). Desative-o antes de ativar outro."
            )))
            return
        }
        activeSheet = StoreSheet(content: .confirmation(patch, enabled: enabled))
    }

    @MainActor
    private func performToggle(
        _ patch: RemotePatch,
        enabled: Bool,
        password: String? = nil,
        riskConfirmed: Bool = false,
        allowChangedTargets: Bool = false
    ) async {
        withAnimation(reduceMotion ? nil : .spring(response: 0.32, dampingFraction: 0.78)) {
            patchActionStates[patch.id] = enabled ? .injecting : .restoring
            activeOperation = PatchOperationPresentation(
                patchName: patch.name,
                isInjection: enabled,
                stage: enabled ? .checkingAccess : .checkingBackup
            )
        }
        defer {
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.22)) {
                patchActionStates.removeValue(forKey: patch.id)
                activeOperation = nil
            }
        }
        let result = await remoteIntegration.setPatchEnabled(
            patch,
            enabled: enabled,
            password: password,
            riskConfirmed: riskConfirmed,
            allowChangedTargets: allowChangedTargets,
            progress: { stage in
                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.24)) {
                    activeOperation?.stage = stage
                }
            }
        )
        switch result {
        case .completed:
            restorePatch = nil
            if !reduceMotion { UINotificationFeedbackGenerator().notificationOccurred(.success) }
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: true,
                isInjection: enabled,
                message: enabled
                    ? "O pacote passou pelas verificaÃ§Ãµes e foi aplicado neste aparelho."
                    : "Os arquivos originais foram restaurados com sucesso."
            )))
        case .requiresRiskConfirmation:
            activeSheet = StoreSheet(content: .confirmation(patch, enabled: true))
        case .requiresPassword:
            passwordValue = ""
            activeSheet = StoreSheet(content: .password(patch))
        case .restoreNeedsConfirmation(let paths):
            restorePatch = patch
            restoreChangedPaths = paths
            showRestoreConfirmation = true
        case .failed(let message):
            if !reduceMotion { UINotificationFeedbackGenerator().notificationOccurred(.error) }
            activeSheet = StoreSheet(content: .result(PatchOperationOutcome(
                patchName: patch.name,
                isSuccess: false,
                isInjection: enabled,
                message: message
            )))
        }
    }

    private func infoRow(symbol: String, title: String, value: String, monospaced: Bool = false) -> some View {
        HStack(alignment: .center, spacing: 11) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(OriginalStorePalette.soft)
                .frame(width: 18)
            Text(title)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(OriginalStorePalette.muted)
            Spacer(minLength: 6)
            Text(value)
                .font(monospaced ? .system(size: 11, weight: .medium, design: .monospaced) : .system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(OriginalStorePalette.white)
                .multilineTextAlignment(.trailing)
                .lineLimit(2)
        }
        .padding(.vertical, 14)
    }

    private var infoDivider: some View {
        Rectangle().fill(OriginalStorePalette.line).frame(height: 1)
    }

    private func statusNotice(_ message: String, symbol: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol).font(.system(size: 13, weight: .semibold)).foregroundStyle(OriginalStorePalette.white)
            Text(message).font(.system(size: 12, weight: .medium)).foregroundStyle(OriginalStorePalette.soft).fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
    }

    private func emptyState(symbol: String, title: String, message: String) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(OriginalStorePalette.soft)
            Text(title)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(OriginalStorePalette.white)
            Text(message)
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(OriginalStorePalette.muted)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
    }

    private func formattedDate(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "NÃ£o informada" }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let date = fractional.date(from: raw) ?? ISO8601DateFormatter().date(from: raw)
        guard let date else { return raw }
        return DateFormatter.localizedString(from: date, dateStyle: .medium, timeStyle: .short)
    }

    private func formattedDate(_ date: Date?) -> String {
        guard let date else { return "Aguardando" }
        return DateFormatter.localizedString(from: date, dateStyle: .none, timeStyle: .short)
    }

    private func remainingLicenseTime(until raw: String?, now: Date) -> String {
        guard let raw, !raw.isEmpty else { return "NÃ£o informada" }
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let expiry = fractional.date(from: raw) ?? ISO8601DateFormatter().date(from: raw) else {
            return "Data indisponÃ­vel"
        }
        let seconds = max(0, Int(ceil(expiry.timeIntervalSince(now))))
        guard seconds > 0 else { return "Expirada" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        let remainingSeconds = seconds % 60
        if days > 0 {
            return String(format: "%d d %02d:%02d:%02d", days, hours, minutes, remainingSeconds)
        }
        return String(format: "%02d:%02d:%02d", hours, minutes, remainingSeconds)
    }
}

private enum PatchActionState: Equatable {
    case injecting
    case restoring

    var title: String {
        switch self {
        case .injecting: return "INJETANDO"
        case .restoring: return "DESINJETANDO"
        }
    }
}

private struct TexturesLibraryView: View {
    @State private var showingImporter = false
    @State private var files: [URL] = []
    @State private var importMessage: String?

    private var texturesDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Texturas", isDirectory: true)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Button {
                showingImporter = true
            } label: {
                Label("Selecionar arquivo .3105", systemImage: "square.and.arrow.down")
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.background)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
            .buttonStyle(.plain)
            .fileImporter(
                isPresented: $showingImporter,
                allowedContentTypes: [.data],
                allowsMultipleSelection: false
            ) { result in
                importFile(result)
            }

            Text("Os arquivos selecionados ficam salvos localmente neste aparelho.")
                .font(.system(size: 12))
                .foregroundStyle(OriginalStorePalette.muted)

            if files.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "square.stack.3d.up")
                        .font(.system(size: 25, weight: .medium))
                        .foregroundStyle(OriginalStorePalette.soft)
                    Text("Nenhuma textura importada")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.white)
                    Text("Escolha um arquivo com extensÃ£o .3105 para adicionÃ¡-lo.")
                        .font(.system(size: 11))
                        .foregroundStyle(OriginalStorePalette.muted)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(24)
                .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
            } else {
                ForEach(files, id: \.lastPathComponent) { file in
                    HStack(spacing: 12) {
                        Image(systemName: "doc.zipper")
                            .foregroundStyle(OriginalStorePalette.soft)
                        Text(file.lastPathComponent)
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(OriginalStorePalette.white)
                            .lineLimit(1)
                        Spacer(minLength: 4)
                        Button {
                            try? FileManager.default.removeItem(at: file)
                            files.removeAll { $0 == file }
                        } label: {
                            Image(systemName: "trash")
                                .foregroundStyle(OriginalStorePalette.muted)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Remover \(file.lastPathComponent)")
                    }
                    .padding(14)
                    .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            }
        }
        .onAppear(perform: loadFiles)
        .alert("ImportaÃ§Ã£o de textura", isPresented: Binding(
            get: { importMessage != nil },
            set: { if !$0 { importMessage = nil } }
        )) {
            Button("OK", role: .cancel) { importMessage = nil }
        } message: {
            Text(importMessage ?? "")
        }
    }

    private func loadFiles() {
        try? FileManager.default.createDirectory(at: texturesDirectory, withIntermediateDirectories: true)
        files = (try? FileManager.default.contentsOfDirectory(
            at: texturesDirectory,
            includingPropertiesForKeys: nil
        ))?.filter { $0.pathExtension.lowercased() == "3105" }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending } ?? []
    }

    private func importFile(_ result: Result<[URL], Error>) {
        do {
            guard let source = try result.get().first else { return }
            guard source.pathExtension.lowercased() == "3105" else {
                importMessage = "Selecione um arquivo com a extensÃ£o .3105."
                return
            }
            try FileManager.default.createDirectory(at: texturesDirectory, withIntermediateDirectories: true)
            let destination = texturesDirectory.appendingPathComponent("\(UUID().uuidString.prefix(8))_\(source.lastPathComponent)")
            let hasAccess = source.startAccessingSecurityScopedResource()
            defer { if hasAccess { source.stopAccessingSecurityScopedResource() } }
            try FileManager.default.copyItem(at: source, to: destination)
            loadFiles()
            importMessage = "Arquivo importado com sucesso."
        } catch {
            importMessage = "NÃ£o foi possÃ­vel importar o arquivo: \(error.localizedDescription)"
        }
    }
}

private enum PatchStatusFilter: CaseIterable, Hashable {
    case all, available, updating, disabled

    var title: String {
        switch self {
        case .all: return "Todos"
        case .available: return "DisponÃ­veis"
        case .updating: return "Atualizando"
        case .disabled: return "Desativados"
        }
    }
}

private enum StoreSheetContent {
    case confirmation(RemotePatch, enabled: Bool)
    case details(RemotePatch)
    case result(PatchOperationOutcome)
    case password(RemotePatch)
}

private struct StoreSheet: Identifiable {
    let id = UUID()
    let content: StoreSheetContent
}

private struct PatchOperationOutcome: Identifiable {
    let id = UUID()
    let patchName: String
    let isSuccess: Bool
    let isInjection: Bool
    let message: String
}

private struct PatchOperationPresentation: Identifiable {
    let id = UUID()
    let patchName: String
    let isInjection: Bool
    var stage: RemotePatchToggleProgress

    var stages: [RemotePatchToggleProgress] {
        isInjection
            ? [.checkingAccess, .downloadingPackage, .verifyingPackage, .preparingPatch, .applyingPatch]
            : [.checkingBackup, .restoringFiles]
    }

    var currentIndex: Int { stages.firstIndex(of: stage) ?? 0 }
}

private struct PatchOperationOverlay: View {
    let operation: PatchOperationPresentation
    let reduceMotion: Bool
    @State private var isRotating = false
    @State private var isPulsing = false

    private var accent: Color {
        operation.isInjection ? Color(red: 0.30, green: 0.78, blue: 0.49) : Color(red: 0.72, green: 0.76, blue: 0.84)
    }

    var body: some View {
        ZStack {
            Color.black.opacity(0.80).ignoresSafeArea()
            Rectangle().fill(.ultraThinMaterial).opacity(0.22).ignoresSafeArea()
            VStack(spacing: 18) {
                VStack(spacing: 5) {
                    Text(operation.isInjection ? "INJETANDO PATCH" : "DESINJETANDO PATCH")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(2.0)
                        .foregroundStyle(accent)
                    Text(operation.patchName)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.white)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                        .minimumScaleFactor(0.8)
                }

                ZStack {
                    Circle().fill(accent.opacity(isPulsing ? 0.16 : 0.08)).frame(width: 126, height: 126)
                        .scaleEffect(isPulsing ? 1.08 : 0.94)
                    Circle().stroke(OriginalStorePalette.line, lineWidth: 2).frame(width: 100, height: 100)
                    Circle()
                        .trim(from: 0.08, to: 0.74)
                        .stroke(accent, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                        .frame(width: 100, height: 100)
                        .rotationEffect(.degrees(isRotating ? 360 : 0))
                    Image(systemName: operation.stage.symbol)
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(accent)
                }
                .frame(height: 130)
                .onAppear {
                    guard !reduceMotion else { return }
                    withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) { isRotating = true }
                    withAnimation(.easeInOut(duration: 1.3).repeatForever(autoreverses: true)) { isPulsing = true }
                }
                .padding(.top, 120)

                VStack(alignment: .leading, spacing: 11) {
                    ForEach(Array(operation.stages.enumerated()), id: \.offset) { index, step in
                        HStack(spacing: 10) {
                            Image(systemName: index < operation.currentIndex ? "checkmark.circle.fill" : (index == operation.currentIndex ? step.symbol : "circle"))
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(index <= operation.currentIndex ? accent : OriginalStorePalette.muted.opacity(0.55))
                                .frame(width: 18)
                            Text(step.title)
                                .font(.system(size: 11, weight: index == operation.currentIndex ? .semibold : .medium, design: .rounded))
                                .foregroundStyle(index == operation.currentIndex ? OriginalStorePalette.white : OriginalStorePalette.muted)
                            Spacer(minLength: 4)
                            if index == operation.currentIndex {
                                ProgressView().controlSize(.mini).tint(accent)
                            }
                        }
                        .accessibilityElement(children: .combine)
                    }
                }
                .padding(14)
                .background(OriginalStorePalette.background.opacity(0.55), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                Text(operation.stage.detail)
                    .font(.system(size: 11, weight: .regular))
                    .foregroundStyle(OriginalStorePalette.muted)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(22)
            .frame(maxWidth: 350)
            .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(accent.opacity(0.25), lineWidth: 1))
            .shadow(color: accent.opacity(0.12), radius: 32, y: 8)
            .padding(.horizontal, 24)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea(.container, edges: .all)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(operation.isInjection ? "Injetando" : "Desinjetando") \(operation.patchName). \(operation.stage.title). \(operation.stage.detail)")
        .zIndex(20)
    }
}

private struct PatchConfirmationSheet: View {
    let patch: RemotePatch
    let isInjection: Bool
    let onCancel: () -> Void
    let onConfirm: () -> Void
    private var accent: Color {
        patch.risk && isInjection ? .orange : (isInjection ? Color(red: 0.30, green: 0.78, blue: 0.49) : OriginalStorePalette.soft)
    }

    var body: some View {
        VStack(spacing: 15) {
            Capsule().fill(OriginalStorePalette.muted.opacity(0.42)).frame(width: 38, height: 4).padding(.top, 5)
            Image(systemName: isInjection ? "bolt.circle.fill" : "arrow.uturn.backward.circle.fill")
                .font(.system(size: 32, weight: .medium))
                .foregroundStyle(accent)
                .frame(width: 72, height: 72)
                .background(accent.opacity(0.12), in: Circle())
                .overlay(Circle().stroke(accent.opacity(0.22), lineWidth: 1))
                .padding(.top, 2)
            VStack(spacing: 5) {
                Text(isInjection ? "Injetar este patch?" : "Desinjetar e restaurar?")
                    .font(.system(size: 21, weight: .bold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.white)
                Text(patch.name)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.soft)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
            }
            Text(isInjection
                 ? "O app confirmarÃ¡ sua licenÃ§a, baixarÃ¡ o pacote e verificarÃ¡ a integridade antes de aplicar as alteraÃ§Ãµes."
                 : "O app verificarÃ¡ o backup e restaurarÃ¡ os arquivos originais salvos neste aparelho.")
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(OriginalStorePalette.muted)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            if isInjection && patch.risk {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill").font(.system(size: 12, weight: .bold))
                    Text("Este item estÃ¡ marcado como Risco. Continue somente se confia na origem do patch.")
                        .font(.system(size: 10, weight: .semibold))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .foregroundStyle(.orange)
                .padding(11)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            Spacer(minLength: 0)
            Button(action: onConfirm) {
                HStack(spacing: 8) {
                    Image(systemName: isInjection ? "bolt.fill" : "arrow.uturn.backward")
                    Text(isInjection ? "Confirmar injeÃ§Ã£o" : "Confirmar restauraÃ§Ã£o")
                }
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(OriginalStorePalette.background)
                .frame(maxWidth: .infinity)
                .frame(height: 50)
                .background(accent, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
            }
            .buttonStyle(.plain)
            Button("Agora nÃ£o", action: onCancel)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(OriginalStorePalette.muted)
                .frame(height: 28)
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 13)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(OriginalStorePalette.background.ignoresSafeArea())
        .presentationDetents([.height(isInjection && patch.risk ? 485 : 455)])
        .presentationDragIndicator(.hidden)
        .preferredColorScheme(.dark)
    }
}

private struct PatchDetailsSheet: View {
    let patch: RemotePatch
    let category: String
    let statusTitle: String
    let statusColor: Color
    let isActive: Bool
    let onClose: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 17) {
                Capsule().fill(OriginalStorePalette.muted.opacity(0.42)).frame(width: 38, height: 4).frame(maxWidth: .infinity).padding(.top, 9)
                HStack(spacing: 13) {
                    Image(systemName: "square.stack.3d.up.fill")
                        .font(.system(size: 21, weight: .semibold))
                        .foregroundStyle(OriginalStorePalette.white)
                        .frame(width: 54, height: 54)
                        .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                    VStack(alignment: .leading, spacing: 5) {
                        Text(patch.name)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(OriginalStorePalette.white)
                            .fixedSize(horizontal: false, vertical: true)
                        Text(category.uppercased())
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(1.6)
                            .foregroundStyle(OriginalStorePalette.muted)
                    }
                }
                HStack(spacing: 7) {
                    detailBadge(statusTitle, color: statusColor)
                    detailBadge(patch.risk ? "Risco" : "Seguro", color: patch.risk ? .orange : Color(red: 0.30, green: 0.78, blue: 0.49))
                    if isActive { detailBadge("Injetado", color: Color(red: 0.30, green: 0.78, blue: 0.49)) }
                }
                VStack(alignment: .leading, spacing: 12) {
                    detailRow("VersÃ£o", value: (patch.version?.isEmpty == false ? patch.version! : "NÃ£o informada"))
                    Rectangle().fill(OriginalStorePalette.line).frame(height: 1)
                    detailRow("Estado", value: statusTitle)
                    Rectangle().fill(OriginalStorePalette.line).frame(height: 1)
                    detailRow("SeguranÃ§a", value: patch.risk ? "Risco â€” use com cautela" : "Seguro")
                }
                .padding(15)
                .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                Text("DESCRIÃ‡ÃƒO")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(OriginalStorePalette.muted)
                Text((patch.description?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false) ? patch.description! : "Nenhuma descriÃ§Ã£o foi adicionada para este patch.")
                    .font(.system(size: 13, weight: .regular))
                    .lineSpacing(4)
                    .foregroundStyle(OriginalStorePalette.soft)
                    .fixedSize(horizontal: false, vertical: true)
                Button(action: onClose) {
                    Text("Fechar detalhes")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
                .padding(.top, 2)
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 20)
        }
        .background(OriginalStorePalette.background.ignoresSafeArea())
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.hidden)
        .preferredColorScheme(.dark)
    }

    private func detailBadge(_ title: String, color: Color) -> some View {
        Text(title)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(color)
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .background(color.opacity(0.13), in: Capsule())
    }

    private func detailRow(_ title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text(title).foregroundStyle(OriginalStorePalette.muted)
            Spacer(minLength: 5)
            Text(value).foregroundStyle(OriginalStorePalette.white).multilineTextAlignment(.trailing)
        }
        .font(.system(size: 11, weight: .medium, design: .rounded))
    }
}

private struct PatchOperationResultSheet: View {
    let result: PatchOperationOutcome
    let onClose: () -> Void
    let onRefresh: () -> Void

    private var accent: Color {
        result.isSuccess ? Color(red: 0.30, green: 0.78, blue: 0.49) : Color(red: 0.94, green: 0.35, blue: 0.36)
    }

    private var title: String {
        if !result.isSuccess { return "NÃ£o foi possÃ­vel concluir" }
        return result.isInjection ? "Patch injetado" : "RestauraÃ§Ã£o concluÃ­da"
    }

    var body: some View {
        VStack(spacing: 15) {
            Capsule().fill(OriginalStorePalette.muted.opacity(0.42)).frame(width: 38, height: 4).padding(.top, 5)
            Image(systemName: result.isSuccess ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                .font(.system(size: 34, weight: .medium))
                .foregroundStyle(accent)
                .frame(width: 78, height: 78)
                .background(accent.opacity(0.12), in: Circle())
            VStack(spacing: 6) {
                Text(title)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.white)
                    .multilineTextAlignment(.center)
                Text(result.patchName)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.soft)
                    .multilineTextAlignment(.center)
            }
            Text(result.message)
                .font(.system(size: 12, weight: .regular))
                .lineSpacing(3)
                .foregroundStyle(OriginalStorePalette.muted)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            if result.isSuccess {
                Button(action: onClose) {
                    Text("ConcluÃ­do")
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 49)
                        .background(accent, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            } else {
                Button(action: onRefresh) {
                    Label("Sincronizar e atualizar catÃ¡logo", systemImage: "arrow.clockwise")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 49)
                        .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                Button("Fechar", action: onClose)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.muted)
                    .frame(height: 25)
            }
        }
        .padding(.horizontal, 22)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(OriginalStorePalette.background.ignoresSafeArea())
        .presentationDetents([.height(result.isSuccess ? 360 : 400)])
        .presentationDragIndicator(.hidden)
        .preferredColorScheme(.dark)
    }
}

private struct PatchSkeletonCard: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isShimmering = false

    var body: some View {
        HStack(spacing: 11) {
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(OriginalStorePalette.raised)
                .frame(width: 44, height: 44)
            VStack(alignment: .leading, spacing: 8) {
                RoundedRectangle(cornerRadius: 5).fill(OriginalStorePalette.raised).frame(width: 130, height: 13)
                HStack(spacing: 6) {
                    Capsule().fill(OriginalStorePalette.raised).frame(width: 72, height: 20)
                    Capsule().fill(OriginalStorePalette.raised).frame(width: 54, height: 20)
                }
            }
            Spacer()
            Capsule().fill(OriginalStorePalette.raised).frame(width: 48, height: 30)
        }
        .padding(14)
        .frame(minHeight: 80)
        .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .fill(LinearGradient(colors: [.clear, OriginalStorePalette.white.opacity(isShimmering ? 0.045 : 0.015), .clear], startPoint: .leading, endPoint: .trailing))
                .allowsHitTesting(false)
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) { isShimmering = true }
        }
        .accessibilityHidden(true)
    }
}

private struct AmbientMotionBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isAnimating = false

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                OriginalStorePalette.background
                Circle()
                    .fill(RadialGradient(
                        colors: [Color.white.opacity(0.11), Color.white.opacity(0.015), .clear],
                        center: .center,
                        startRadius: 0,
                        endRadius: 210
                    ))
                    .frame(width: 420, height: 420)
                    .offset(
                        x: (isAnimating ? 0.28 : -0.28) * geometry.size.width,
                        y: (isAnimating ? -0.24 : -0.38) * geometry.size.height
                    )
                Circle()
                    .fill(RadialGradient(
                        colors: [Color(red: 0.55, green: 0.58, blue: 0.64).opacity(0.12), .clear],
                        center: .center,
                        startRadius: 0,
                        endRadius: 180
                    ))
                    .frame(width: 360, height: 360)
                    .offset(
                        x: (isAnimating ? -0.30 : 0.32) * geometry.size.width,
                        y: (isAnimating ? 0.38 : 0.18) * geometry.size.height
                    )
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .clipped()
            .onAppear {
                guard !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 13).repeatForever(autoreverses: true)) {
                    isAnimating = true
                }
            }
        }
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }
}

private enum AccessGateKind {
    case configuration, connection, maintenance, offline, updating, oldVersion, banned
    case keyMissing, keyRevoked, keyExpired, keyDisabled, invalidKey, deviceLimit, deviceMismatch

    var symbol: String {
        switch self {
        case .configuration: return "gearshape.2.fill"
        case .connection: return "wifi.slash"
        case .maintenance: return "wrench.and.screwdriver.fill"
        case .offline: return "power"
        case .updating: return "arrow.triangle.2.circlepath"
        case .oldVersion: return "arrow.down.app.fill"
        case .banned: return "iphone.slash"
        case .keyMissing: return "key.slash.fill"
        case .keyRevoked: return "xmark.shield.fill"
        case .keyExpired: return "calendar.badge.exclamationmark"
        case .keyDisabled: return "pause.circle.fill"
        case .invalidKey: return "key.fill"
        case .deviceLimit: return "iphone.gen3.radiowaves.left.and.right"
        case .deviceMismatch: return "iphone.and.arrow.forward"
        }
    }

    var title: String {
        switch self {
        case .configuration: return "ServiÃ§o nÃ£o configurado"
        case .connection: return "Sem conexÃ£o com a loja"
        case .maintenance: return "Estamos em manutenÃ§Ã£o"
        case .offline: return "ServiÃ§o temporariamente desligado"
        case .updating: return "Loja em atualizaÃ§Ã£o"
        case .oldVersion: return "Atualize o aplicativo"
        case .banned: return "Dispositivo bloqueado"
        case .keyMissing: return "Key nÃ£o encontrada"
        case .keyRevoked: return "Acesso revogado"
        case .keyExpired: return "Key expirada"
        case .keyDisabled: return "Key desativada"
        case .invalidKey: return "NÃ£o foi possÃ­vel validar a key"
        case .deviceLimit: return "Limite de aparelhos atingido"
        case .deviceMismatch: return "Key vinculada a outro aparelho"
        }
    }

    var requiresNewKey: Bool {
        switch self {
        case .keyMissing, .keyRevoked, .keyExpired, .keyDisabled, .invalidKey, .deviceLimit, .deviceMismatch: return true
        default: return false
        }
    }

    @MainActor
    func message(service: RemoteIntegration) -> String {
        switch self {
        case .configuration:
            return service.gateMessage ?? "Esta versÃ£o ainda nÃ£o estÃ¡ conectada Ã  origem da API."
        case .connection:
            return service.errorMessage ?? "Verifique sua conexÃ£o e tente novamente."
        case .maintenance:
            return service.gateMessage ?? "A equipe estÃ¡ realizando uma manutenÃ§Ã£o. Tente novamente mais tarde."
        case .offline:
            return service.gateMessage ?? "O acesso Ã  loja estÃ¡ temporariamente pausado."
        case .updating:
            return service.gateMessage ?? "Estamos atualizando o serviÃ§o. Tente novamente em alguns minutos."
        case .oldVersion:
            return service.gateMessage ?? "Instale a versÃ£o mais recente para continuar."
        case .banned:
            return service.gateMessage ?? "Este aparelho foi bloqueado pelo administrador. Entre em contato com o suporte."
        case .keyMissing:
            return "Esta key nÃ£o existe ou foi excluÃ­da. Confira o cÃ³digo ou solicite uma nova key ao administrador."
        case .keyRevoked:
            return "O acesso desta key foi revogado. Solicite uma nova licenÃ§a ao administrador da loja."
        case .keyExpired:
            return "O perÃ­odo desta key terminou. Solicite uma nova licenÃ§a para continuar."
        case .keyDisabled:
            return "O administrador desativou esta licenÃ§a. Entre em contato com a loja para confirmar o acesso."
        case .invalidKey:
            return service.errorMessage ?? "Confira todos os caracteres da key e tente novamente."
        case .deviceLimit:
            return "Esta key jÃ¡ alcanÃ§ou o limite de aparelhos permitido. PeÃ§a ao administrador para liberar um vÃ­nculo ou use outra key."
        case .deviceMismatch:
            return "Esta key estÃ¡ vinculada a outro aparelho. Fale com o administrador para revisar o vÃ­nculo."
        }
    }
}

private struct AccessStatusView: View {
    let state: AccessGateKind
    @ObservedObject var service: RemoteIntegration
    let onRetry: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 24) {
                HStack(spacing: 13) {
                    OriginalStoreBrandMark(size: 52)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .foregroundStyle(OriginalStorePalette.white)
                        Text("STATUS DO ACESSO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(OriginalStorePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 18) {
                    Image(systemName: state.symbol)
                        .font(.system(size: 24, weight: .medium))
                        .foregroundStyle(OriginalStorePalette.white)
                        .frame(width: 58, height: 58)
                        .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    VStack(alignment: .leading, spacing: 9) {
                        Text(state.title)
                            .font(.system(size: 27, weight: .bold, design: .rounded))
                            .tracking(-0.7)
                            .foregroundStyle(OriginalStorePalette.white)
                        Text(state.message(service: service))
                            .font(.system(size: 14, weight: .regular))
                            .lineSpacing(4)
                            .foregroundStyle(OriginalStorePalette.muted)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    if !service.maskedLicenseKey.isEmpty && service.maskedLicenseKey != "â€”" {
                        Text(service.maskedLicenseKey)
                            .font(.system(size: 11, weight: .medium, design: .monospaced))
                            .foregroundStyle(OriginalStorePalette.soft)
                            .padding(.horizontal, 11)
                            .padding(.vertical, 8)
                            .background(OriginalStorePalette.raised, in: Capsule())
                    }
                }
                .padding(20)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

                if state.requiresNewKey {
                    Button {
                        service.prepareForKeyEntry()
                    } label: {
                        HStack(spacing: 9) {
                            Text("Inserir outra key")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                } else {
                    Button(action: onRetry) {
                        HStack(spacing: 9) {
                            if service.isLoading { ProgressView().tint(OriginalStorePalette.background) }
                            Text("Tentar novamente")
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 12, weight: .semibold))
                        }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .disabled(service.isLoading)
                }

                if let discordURL = service.discordURL {
                    Link(destination: discordURL) {
                        HStack(spacing: 10) {
                            DiscordGlyph(size: 18)
                            Text("Falar com o suporte no Discord")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                        }
                        .foregroundStyle(OriginalStorePalette.soft)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
                    }
                }

                Text("Desenvolvido por @OriginalStore")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(OriginalStorePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 2)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct DiscordGlyph: View {
    let size: CGFloat

    var body: some View {
        ZStack {
            DiscordControllerShape().fill(OriginalStorePalette.white)
            HStack(spacing: size * 0.16) {
                Circle().fill(OriginalStorePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
                Circle().fill(OriginalStorePalette.background)
                    .frame(width: size * 0.105, height: size * 0.105)
            }
            .offset(y: size * 0.07)
        }
        .frame(width: size, height: size * 0.82)
        .accessibilityHidden(true)
    }
}

private struct DiscordControllerShape: Shape {
    func path(in rect: CGRect) -> Path {
        let w = rect.width
        let h = rect.height
        var path = Path()
        path.move(to: CGPoint(x: w * 0.27, y: h * 0.15))
        path.addQuadCurve(to: CGPoint(x: w * 0.73, y: h * 0.15), control: CGPoint(x: w * 0.50, y: -h * 0.04))
        path.addQuadCurve(to: CGPoint(x: w * 0.87, y: h * 0.71), control: CGPoint(x: w * 0.83, y: h * 0.30))
        path.addQuadCurve(to: CGPoint(x: w * 0.64, y: h * 0.84), control: CGPoint(x: w * 0.78, y: h * 0.91))
        path.addLine(to: CGPoint(x: w * 0.58, y: h * 0.70))
        path.addQuadCurve(to: CGPoint(x: w * 0.42, y: h * 0.70), control: CGPoint(x: w * 0.50, y: h * 0.75))
        path.addLine(to: CGPoint(x: w * 0.36, y: h * 0.84))
        path.addQuadCurve(to: CGPoint(x: w * 0.13, y: h * 0.71), control: CGPoint(x: w * 0.22, y: h * 0.91))
        path.addQuadCurve(to: CGPoint(x: w * 0.27, y: h * 0.15), control: CGPoint(x: w * 0.17, y: h * 0.30))
        path.closeSubpath()
        return path
    }
}

private struct OriginalStoreKeyEntryView: View {
    @ObservedObject var service: RemoteIntegration
    let onRestore: (RemotePatch) -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 25) {
                HStack(spacing: 13) {
                    OriginalStoreBrandMark(size: 54)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(service.storeName)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                            .foregroundStyle(OriginalStorePalette.white)
                        Text("SEVEN CHEATS Â· ACESSO SEGURO")
                            .font(.system(size: 9, weight: .semibold, design: .rounded))
                            .tracking(2.5)
                            .foregroundStyle(OriginalStorePalette.muted)
                    }
                }
                .padding(.top, 34)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Desbloqueie\nseu acesso")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                        .tracking(-1.1)
                        .foregroundStyle(OriginalStorePalette.white)
                    Text("Informe sua key Original Store para validar a licenÃ§a e vincular este aparelho com seguranÃ§a.")
                        .font(.system(size: 13, weight: .regular))
                        .lineSpacing(4)
                        .foregroundStyle(OriginalStorePalette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.top, 14)

                HStack(spacing: 10) {
                    Image(systemName: "checkmark.shield.fill")
                        .font(.system(size: 15, weight: .medium))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("VALIDAÃ‡ÃƒO PROTEGIDA")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(1.5)
                        Text("ConexÃ£o segura Â· vÃ­nculo por dispositivo")
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                    }
                    Spacer(minLength: 0)
                    Circle()
                        .fill(service.isLoading ? OriginalStorePalette.soft : OriginalStorePalette.white.opacity(0.8))
                        .frame(width: 6, height: 6)
                        .accessibilityHidden(true)
                }
                .foregroundStyle(OriginalStorePalette.soft)
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(OriginalStorePalette.surface.opacity(0.68), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

                VStack(alignment: .leading, spacing: 10) {
                    Text("SUA KEY")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2)
                        .foregroundStyle(OriginalStorePalette.muted)
                    HStack(spacing: 11) {
                        Image(systemName: "key.horizontal.fill")
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(OriginalStorePalette.soft)
                        TextField("Cole sua key Original Store", text: $service.licenseKey)
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .keyboardType(.asciiCapable)
                            .submitLabel(.go)
                            .onSubmit { Task { await service.activateOrValidate(key: service.licenseKey) } }
                            .foregroundStyle(OriginalStorePalette.white)
                    }
                    .padding(.horizontal, 15)
                    .frame(height: 57)
                    .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

                    if let message = service.errorMessage ?? service.gateMessage, !message.isEmpty {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "exclamationmark.circle.fill")
                                .font(.system(size: 12))
                            Text(message)
                                .font(.system(size: 12, weight: .medium))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .foregroundStyle(OriginalStorePalette.soft)
                        .padding(.top, 4)
                    }

                    if !service.isConfigured {
                        Text("O serviÃ§o do catÃ¡logo ainda nÃ£o estÃ¡ configurado nesta versÃ£o do app. Entre em contato com o suporte.")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(OriginalStorePalette.muted)
                            .padding(.top, 5)
                    }
                }
                .padding(17)
                .background(OriginalStorePalette.surface.opacity(0.72), in: RoundedRectangle(cornerRadius: 21, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))

                Button {
                    Task { await service.activateOrValidate(key: service.licenseKey) }
                } label: {
                    HStack(spacing: 9) {
                        if service.isLoading {
                            ProgressView().tint(OriginalStorePalette.background)
                        } else {
                            Text("Validar licenÃ§a")
                            Image(systemName: "arrow.right")
                                .font(.system(size: 13, weight: .semibold))
                        }
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.background)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .disabled(service.isLoading || !service.isConfigured || service.licenseKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(service.isLoading || !service.isConfigured ? 0.65 : 1)

                if !service.recoveryPatches.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 8) {
                            Image(systemName: "arrow.uturn.backward.circle.fill")
                            Text("RESTAURAÃ‡ÃƒO LOCAL")
                                .tracking(1.8)
                        }
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.soft)
                        Text("A licenÃ§a nÃ£o estÃ¡ ativa. VocÃª ainda pode desligar um patch aplicado para restaurar os arquivos originais.")
                            .font(.system(size: 11, weight: .regular))
                            .lineSpacing(3)
                            .foregroundStyle(OriginalStorePalette.muted)
                        ForEach(service.recoveryPatches) { patch in
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(patch.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(OriginalStorePalette.white)
                                    Text("Aplicado neste aparelho").font(.system(size: 10, weight: .medium)).foregroundStyle(OriginalStorePalette.muted)
                                }
                                Spacer()
                                Toggle(
                                    "",
                                    isOn: Binding(
                                        get: { service.isPatchActive(patch.id) },
                                        set: { if !$0 { onRestore(patch) } }
                                    )
                                )
                                .labelsHidden()
                                .toggleStyle(SwitchToggleStyle(tint: OriginalStorePalette.white))
                                .disabled(service.isPatchBusy(patch.id))
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    .padding(16)
                    .background(OriginalStorePalette.surface, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(OriginalStorePalette.line, lineWidth: 1))
                }

                Text("Desenvolvido por @OriginalStore")
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .tracking(1.8)
                    .foregroundStyle(OriginalStorePalette.muted.opacity(0.8))
                    .frame(maxWidth: .infinity)
                    .padding(.top, 4)
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 23)
        }
        .scrollDismissesKeyboard(.interactively)
    }
}

private struct OriginalStoreBrandMark: View {
    var size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .fill(OriginalStorePalette.raised)
            RoundedRectangle(cornerRadius: size * 0.32, style: .continuous)
                .stroke(OriginalStorePalette.line, lineWidth: 1)
            Image(systemName: "person.fill")
                .font(.system(size: size * 0.39, weight: .medium))
                .foregroundStyle(OriginalStorePalette.white)
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Perfil da licenÃ§a")
    }
}

private struct PatchPasswordSheet: View {
    let patchName: String
    @Binding var password: String
    let onCancel: () -> Void
    let onUnlock: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 18) {
                Text("Este pacote estÃ¡ protegido por senha.")
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                    .foregroundStyle(OriginalStorePalette.white)
                Text(patchName)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(OriginalStorePalette.muted)
                SecureField("Senha do pacote", text: $password)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focused)
                    .padding(14)
                    .background(OriginalStorePalette.raised, in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                Button(action: onUnlock) {
                    Text("Desbloquear e continuar")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundStyle(OriginalStorePalette.background)
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .background(OriginalStorePalette.white, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .disabled(password.isEmpty)
                Spacer(minLength: 0)
            }
            .padding(20)
            .background(OriginalStorePalette.background.ignoresSafeArea())
            .navigationTitle("Desbloquear pacote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar", action: onCancel).foregroundStyle(OriginalStorePalette.soft)
                }
            }
            .onAppear { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { focused = true } }
        }
        .preferredColorScheme(.dark)
    }
}

