# Original Store — catálogo Vercel e redesign

## Direção visual
- **Movimentos considerados:** neon editorial roxo/preto (0,06), dashboard utilitário (0,04), arcade cromado (0,03). Escolhido: neon editorial roxo/preto.
- **Princípios:** contraste alto, hierarquia curta, cartões com borda violeta, estados de serviço sempre visíveis.
- **Paleta:** preto quase absoluto para foco; violeta elétrico para ações; lavanda para informação; âmbar/vermelho apenas para avisos.
- **Layout:** cabeçalho compacto, banner de identidade, ação “Atualizar patches” em destaque e catálogos separados por tipo.
- **Elementos de assinatura:** brilho violeta discreto, banner anime monocromático e chips de status.
- **Interação:** ações de sincronização devem ter feedback imediato e nunca apagar o fallback local.
- **Tipografia:** SF Rounded para títulos e SF Mono em estados técnicos.
- **Essência:** uma loja de patches organizada, rápida e transparente. Personalidade: técnica, direta, cuidadosa.

## Implementação
- O iOS consome `GET /api/catalog`, com compatibilidade para o endpoint legado `/api/mobile/catalog`.
- Em falha de rede, o app monta um catálogo local a partir de `Resources/OriginalStore/Patches` e `Resources/OriginalStore/Textures`.
- O painel Vercel expõe `GET /api/catalog`, `GET /api/status` e `POST /api/admin/upload`; o upload usa Vercel Blob e exige `ADMIN_UPLOAD_TOKEN` somente no servidor.
- O site não embute credenciais administrativas no app. O iOS usa apenas a URL pública do catálogo.
- Estados suportados: `online`, `maintenance` e `offline`, configuráveis por `STATUS_MODE`/`STATUS_MESSAGE` ou pelo painel protegido.

## Estrutura
- `catalog-site/index.html`: painel simples para listar estado e enviar `.3105`.
- `catalog-site/api/catalog.js`: catálogo público.
- `catalog-site/api/status.js`: status público.
- `catalog-site/api/admin/upload.js`: upload administrativo.
- `catalog-site/api/_lib/catalog.js`: leitura/escrita de metadados no Blob.
- `catalog-site/vercel.json`: roteamento e headers.
