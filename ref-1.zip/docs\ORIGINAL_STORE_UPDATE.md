# Atualização Original Store

- Nome exibido: Original Store.
- Endpoint de validação: https://original-key-control.vercel.app/api/public/validate
- Payload: key, hwid e application_id.
- Application ID: 4b2b26e0-74dc-43b9-b4f2-808bee494183.
- A credencial app_... não foi embutida: o payload fornecido não a exige e credenciais estáticas em apps iOS podem ser extraídas.
- Namespace local de licença: com.originalstore.3106.remote.
- Componentes de jailbreak/exploit/anti-detecção: não alterados.

## Recursos externos pendentes

Os dois arquivos do MediaFire não foram incorporados porque os downloads ficaram inacessíveis neste ambiente:

- https://www.mediafire.com/file/0qpv5fm0xg70w9a/Colocar+na+aba+Ptachs.rar/file
- https://www.mediafire.com/file/4kpga68fx3e841d/adiciona+na+aba+texturas.zip/file

## Recursos incorporados

Os 13 arquivos .3105 dos dois arquivos recebidos foram adicionados em Resources/OriginalStore/Patches e Resources/OriginalStore/Textures. O backend de nuvem não foi alterado, pois nenhum acesso administrativo ao servidor/catalogo foi fornecido; os recursos estão incluídos no código-fonte atualizado para publicação no catálogo.

